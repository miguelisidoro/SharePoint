export interface ICustomerModalEditState {
    key: string;
    name: string;
    value: string;
    showModal:boolean;
}