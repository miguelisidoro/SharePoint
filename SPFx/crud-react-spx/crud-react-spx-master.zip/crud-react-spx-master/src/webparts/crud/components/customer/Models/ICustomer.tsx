export interface ICustomer {
    key: number;
    name: string;
    value: string;
}