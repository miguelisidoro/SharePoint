import {ICustomer} from './ICustomer';
export class Customer implements ICustomer {
    key: number;
    name: string;
    value: string;
}
