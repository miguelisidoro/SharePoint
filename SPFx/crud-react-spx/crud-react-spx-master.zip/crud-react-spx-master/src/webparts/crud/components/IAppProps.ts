export interface IAppProps {
  description: string;
}
